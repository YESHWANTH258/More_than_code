from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SelectField, TextAreaField, DateField, FileField, IntegerField, SubmitField
from wtforms.validators import DataRequired, Email, Length, EqualTo, ValidationError, Optional, NumberRange
from flask_wtf.file import FileRequired, FileAllowed
from datetime import datetime
from models import User

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember = BooleanField('Remember Me')
    submit = SubmitField('Login')

class RegistrationForm(FlaskForm):
    name = StringField('Name', validators=[DataRequired(), Length(min=2, max=100)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    role = SelectField('Role', choices=[('student', 'Student'), ('teacher', 'Teacher')], validators=[DataRequired()])
    submit = SubmitField('Register')

    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError('Email already registered. Please use a different email.')

class AssignmentForm(FlaskForm):
    title = StringField('Title', validators=[DataRequired(), Length(min=3, max=200)])
    description = TextAreaField('Description', validators=[DataRequired()])
    type = SelectField('Type', choices=[
        ('essay', 'Essay'),
        ('quiz', 'Quiz'),
        ('project', 'Project'),
        ('presentation', 'Presentation')
    ], validators=[DataRequired()])
    due_date = DateField('Due Date', validators=[DataRequired()])
    study_material = FileField('Study Material', validators=[
        Optional(),
        FileAllowed(['pdf', 'doc', 'docx', 'zip'], 'Only PDF, DOC, DOCX, and ZIP files are allowed!')
    ])
    max_score = IntegerField('Maximum Score', validators=[DataRequired(), NumberRange(min=0, max=100)])
    ai_assistance = BooleanField('Enable AI Assistance')
    submit = SubmitField('Create Assignment')

    def validate_due_date(self, due_date):
        if due_date.data < datetime.now().date():
            raise ValidationError('Due date must be in the future.')

class SubmissionForm(FlaskForm):
    file = FileField('Submission File', validators=[
        FileRequired(),
        FileAllowed(['pdf', 'doc', 'docx', 'zip'], 'Only PDF, DOC, DOCX, and ZIP files are allowed!')
    ])
    comments = TextAreaField('Comments', validators=[Optional()])
    submit = SubmitField('Submit Assignment')

class GradeSubmissionForm(FlaskForm):
    score = IntegerField('Score', validators=[DataRequired(), NumberRange(min=0, max=100)])
    feedback = TextAreaField('Feedback', validators=[DataRequired()])
    submit = SubmitField('Grade Submission')

class AIQueryForm(FlaskForm):
    query = TextAreaField('Your Question', validators=[DataRequired(), Length(min=10)])
    submit = SubmitField('Ask AI') 