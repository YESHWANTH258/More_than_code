# AI Assignment Management System

A modern web application for managing assignments with AI-powered features for both educators and students.

## Features

- **User Authentication**
  - Separate roles for educators and students
  - Secure login and registration system

- **Assignment Management**
  - Create and manage assignments
  - Support for multiple assignment types
  - File upload and download capabilities
  - Due date tracking

- **AI-Powered Features**
  - Plagiarism detection
  - Quality assessment
  - Automated feedback generation
  - AI query handler for student assistance

- **Grading System**
  - Score tracking
  - Detailed feedback
  - Progress monitoring

## Prerequisites

- Python 3.8 or higher
- pip (Python package installer)
- Virtual environment (recommended)

## Installation

1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd ai_assignment_system
   ```

2. Create and activate a virtual environment:
   ```bash
   # Windows
   python -m venv venv
   .\venv\Scripts\activate

   # Linux/Mac
   python3 -m venv venv
   source venv/bin/activate
   ```

3. Install the required packages:
   ```bash
   pip install -r requirements.txt
   ```

4. Create a `.env` file in the project root with the following variables:
   ```
   SECRET_KEY=your-secret-key-here
   DATABASE_URL=sqlite:///assignment_system.db
   OPENAI_API_KEY=your-openai-api-key
   ```

5. Initialize the database:
   ```bash
   python app.py
   ```

## Running the Application

1. Make sure your virtual environment is activated.

2. Start the Flask development server:
   ```bash
   python app.py
   ```

3. Open your web browser and navigate to:
   ```
   http://localhost:5000
   ```

## Project Structure

```
ai_assignment_system/
├── app.py                 # Main application file
├── requirements.txt       # Python dependencies
├── .env                  # Environment variables
├── README.md            # Project documentation
├── static/              # Static files (CSS, JS, images)
├── templates/           # HTML templates
│   ├── base.html
│   ├── login.html
│   ├── register.html
│   ├── dashboard.html
│   ├── create_assignment.html
│   ├── submit_assignment.html
│   ├── view_submission.html
│   └── view_submissions.html
└── uploads/             # File upload directory
    ├── assignments/
    └── submissions/
```

## Usage

### For Educators

1. Register as an educator
2. Create new assignments
3. Upload study materials
4. Review student submissions
5. Grade assignments and provide feedback
6. View AI analysis of submissions

### For Students

1. Register as a student
2. View available assignments
3. Download study materials
4. Submit assignments
5. Receive AI-powered feedback
6. Ask questions using the AI query handler

## Security Considerations

- All passwords are hashed using secure algorithms
- File uploads are validated and sanitized
- API keys are stored securely in environment variables
- User sessions are managed securely

## Contributing

1. Fork the repository
2. Create a new branch for your feature
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support, please open an issue in the repository or contact the development team. 