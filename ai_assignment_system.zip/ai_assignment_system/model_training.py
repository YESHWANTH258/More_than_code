from transformers import AutoModelForSeq2SeqLM, AutoTokenizer, TrainingArguments, Trainer
from datasets import Dataset
import torch
import json
import os
from PyPDF2 import PdfReader
from app import app, ASSIGNMENTS_FOLDER
from models import Assignment

def read_file_content(file_path):
    """Read content from different file types"""
    file_extension = os.path.splitext(file_path)[1].lower()
    
    if file_extension == '.pdf':
        # Handle PDF files
        reader = PdfReader(file_path)
        text = ""
        for page in reader.pages:
            text += page.extract_text() + "\n"
        return text
    else:
        # Handle text files
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()

def create_training_data():
    """Create training data from uploaded documents"""
    training_data = []
    
    # Get all assignments with study materials
    assignments = Assignment.query.filter(Assignment.study_material_path.isnot(None)).all()
    
    for assignment in assignments:
        # Read the study material
        file_path = os.path.join(ASSIGNMENTS_FOLDER, assignment.study_material_path)
        try:
            content = read_file_content(file_path)
            
            # Create training examples
            # Split content into chunks for better context
            chunks = [content[i:i+1000] for i in range(0, len(content), 1000)]
            
            for chunk in chunks:
                # Create question-answer pairs
                training_data.extend([
                    {
                        "input_text": f"Context: This is about {assignment.title}.\nContent: {chunk}\nQuestion: What is this document about?",
                        "target_text": f"This document is about {assignment.title}. It contains the following content: {chunk[:150]}..."
                    },
                    {
                        "input_text": f"Context: This is about {assignment.title}.\nContent: {chunk}\nQuestion: What are the key points in this document?",
                        "target_text": f"The key points in this document are: {chunk[:200]}..."
                    },
                    {
                        "input_text": f"Context: This is about {assignment.title}.\nContent: {chunk}\nQuestion: Can you explain this content?",
                        "target_text": f"Let me explain this content: {chunk[:200]}..."
                    },
                    {
                        "input_text": f"Context: This is about {assignment.title}.\nContent: {chunk}\nQuestion: What are the main concepts discussed?",
                        "target_text": f"The main concepts discussed are: {chunk[:200]}..."
                    },
                    {
                        "input_text": f"Context: This is about {assignment.title}.\nContent: {chunk}\nQuestion: Can you summarize this section?",
                        "target_text": f"Here's a summary of this section: {chunk[:200]}..."
                    }
                ])
        except Exception as e:
            print(f"Error processing file {file_path}: {str(e)}")
            continue
    
    return training_data

def prepare_dataset(training_data):
    """Prepare the dataset for training"""
    dataset = Dataset.from_dict({
        "input_text": [item["input_text"] for item in training_data],
        "target_text": [item["target_text"] for item in training_data]
    })
    return dataset

def train_model():
    """Fine-tune the model on the training data"""
    # Initialize model and tokenizer
    model_name = "google/flan-t5-small"
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForSeq2SeqLM.from_pretrained(model_name)
    
    # Create training data
    training_data = create_training_data()
    if not training_data:
        print("No training data available")
        return
    
    # Prepare dataset
    dataset = prepare_dataset(training_data)
    
    # Define training arguments
    training_args = TrainingArguments(
        output_dir="./fine_tuned_model",
        num_train_epochs=5,  # Increased epochs for better learning
        per_device_train_batch_size=4,
        save_steps=100,
        save_total_limit=2,
        logging_dir="./logs",
        learning_rate=2e-5,  # Added learning rate
        warmup_steps=500,    # Added warmup steps
        weight_decay=0.01,   # Added weight decay
        remove_unused_columns=False,  # Allow custom columns
        label_names=["target_text"],  # Specify label column
        input_names=["input_text"],   # Specify input column
    )
    
    # Initialize trainer
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=dataset,
    )
    
    # Train the model
    trainer.train()
    
    # Save the fine-tuned model
    model.save_pretrained("./fine_tuned_model")
    tokenizer.save_pretrained("./fine_tuned_model")
    
    print("Model fine-tuning completed!")

if __name__ == "__main__":
    with app.app_context():
        train_model() 