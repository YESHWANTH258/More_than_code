from flask import render_template, request, redirect, url_for, flash, jsonify, send_from_directory
from flask_login import login_user, login_required, logout_user, current_user
from werkzeug.utils import secure_filename
from app import app, db, mail, allowed_file, ASSIGNMENTS_FOLDER, SUBMISSIONS_FOLDER
from models import User, Assignment, Submission
from forms import LoginForm, RegistrationForm, AssignmentForm, SubmissionForm
import os
from datetime import datetime
import openai
from transformers import AutoModelForSeq2SeqLM, AutoTokenizer
import torch
from PyPDF2 import PdfReader

# Initialize the model and tokenizer (do this at the top level)
# Using the pre-trained model directly since fine-tuned model is not available or properly configured
model_path = "google/flan-t5-small"
tokenizer = AutoTokenizer.from_pretrained(model_path)
model = AutoModelForSeq2SeqLM.from_pretrained(model_path)

def read_file_content(file_path):
    """Read content from different file types"""
    file_extension = os.path.splitext(file_path)[1].lower()
    
    if file_extension == '.pdf':
        # Handle PDF files
        reader = PdfReader(file_path)
        text = ""
        for page in reader.pages:
            text += page.extract_text() + "\n"
        return text
    else:
        # Handle text files
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()

# Authentication routes
@app.route('/')
@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user)
            return redirect(url_for('dashboard'))
        flash('Invalid email or password', 'error')
    return render_template('login.html', form=form)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    form = RegistrationForm()
    if form.validate_on_submit():
        user = User(
            name=form.name.data,
            email=form.email.data,
            role=form.role.data
        )
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html', form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

# Dashboard
@app.route('/dashboard')
@login_required
def dashboard():
    if current_user.role == 'teacher':
        assignments = Assignment.query.filter_by(creator_id=current_user.id).all()
        recent_submissions = Submission.query.join(Assignment).filter(
            Assignment.creator_id == current_user.id
        ).order_by(Submission.submitted_at.desc()).limit(5).all()
        pending_grades = Submission.query.join(Assignment).filter(
            Assignment.creator_id == current_user.id,
            Submission.score.is_(None)
        ).count()
        total_students = User.query.filter_by(role='student').count()
        return render_template('dashboard.html', 
                             assignments=assignments,
                             recent_submissions=recent_submissions,
                             pending_grades=pending_grades,
                             total_students=total_students)
    else:
        # Get all assignments
        all_assignments = Assignment.query.all()
        
        # Get student's submissions
        student_submissions = Submission.query.filter_by(student_id=current_user.id).all()
        submitted_assignment_ids = [sub.assignment_id for sub in student_submissions]
        
        # Filter pending assignments (not submitted yet)
        pending_assignments = [ass for ass in all_assignments if ass.id not in submitted_assignment_ids]
        
        # Calculate statistics
        submitted_count = len(student_submissions)
        graded_submissions = [sub for sub in student_submissions if sub.score is not None]
        average_score = sum(sub.score for sub in graded_submissions) / len(graded_submissions) if graded_submissions else None
        
        return render_template('dashboard.html',
                             pending_assignments=pending_assignments,
                             submission_history=student_submissions,
                             submitted_count=submitted_count,
                             average_score=average_score)

# Assignment routes
@app.route('/assignment/create', methods=['GET', 'POST'])
@login_required
def create_assignment():
    if current_user.role != 'teacher':
        flash('Only teachers can create assignments', 'error')
        return redirect(url_for('dashboard'))
    
    form = AssignmentForm()
    if form.validate_on_submit():
        assignment = Assignment(
            title=form.title.data,
            description=form.description.data,
            type=form.type.data,
            due_date=form.due_date.data,
            max_score=form.max_score.data,
            ai_assistance=form.ai_assistance.data,
            creator_id=current_user.id
        )
        
        if form.study_material.data:
            file = form.study_material.data
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file_path = os.path.join(ASSIGNMENTS_FOLDER, filename)
                file.save(file_path)
                assignment.study_material_path = filename
        
        db.session.add(assignment)
        db.session.commit()
        flash('Assignment created successfully!', 'success')
        return redirect(url_for('dashboard'))
    
    return render_template('create_assignment.html', form=form)

@app.route('/assignment/<int:assignment_id>')
@login_required
def view_assignment(assignment_id):
    assignment = Assignment.query.get_or_404(assignment_id)
    return render_template('view_assignment.html', assignment=assignment)

@app.route('/assignment/<int:assignment_id>/submissions')
@login_required
def grade_submissions(assignment_id):
    if current_user.role != 'teacher':
        flash('Only teachers can view submissions', 'error')
        return redirect(url_for('dashboard'))
    
    assignment = Assignment.query.get_or_404(assignment_id)
    if assignment.creator_id != current_user.id:
        flash('You do not have permission to view these submissions', 'error')
        return redirect(url_for('dashboard'))
    
    submissions = Submission.query.filter_by(assignment_id=assignment_id).all()
    return render_template('grade_submissions.html', assignment=assignment, submissions=submissions)

# Submission routes
@app.route('/assignment/<int:assignment_id>/submit', methods=['GET', 'POST'])
@login_required
def submit_assignment(assignment_id):
    if current_user.role != 'student':
        flash('Only students can submit assignments', 'error')
        return redirect(url_for('dashboard'))
    
    assignment = Assignment.query.get_or_404(assignment_id)
    form = SubmissionForm()
    
    if form.validate_on_submit():
        submission = Submission(
            assignment_id=assignment_id,
            student_id=current_user.id,
            comments=form.comments.data
        )
        
        if form.file.data:
            file = form.file.data
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file_path = os.path.join(SUBMISSIONS_FOLDER, filename)
                file.save(file_path)
                submission.file_path = filename
        
        db.session.add(submission)
        db.session.commit()
        flash('Assignment submitted successfully!', 'success')
        return redirect(url_for('dashboard'))
    
    return render_template('submit_assignment.html', form=form, assignment=assignment)

@app.route('/submission/<int:submission_id>')
@login_required
def view_submission(submission_id):
    submission = Submission.query.get_or_404(submission_id)
    if current_user.role == 'teacher' and submission.assignment.creator_id != current_user.id:
        flash('You do not have permission to view this submission', 'error')
        return redirect(url_for('dashboard'))
    return render_template('view_submission.html', submission=submission)

@app.route('/submission/<int:submission_id>/grade', methods=['GET', 'POST'])
@login_required
def grade_submission(submission_id):
    if current_user.role != 'teacher':
        flash('Only teachers can grade submissions', 'error')
        return redirect(url_for('dashboard'))
    
    submission = Submission.query.get_or_404(submission_id)
    if submission.assignment.creator_id != current_user.id:
        flash('You do not have permission to grade this submission', 'error')
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        score = int(request.form.get('score'))
        feedback = request.form.get('feedback')
        
        if 0 <= score <= submission.assignment.max_score:
            submission.grade(score, feedback)
            flash('Submission graded successfully!', 'success')
            
            # Send email notification to student
            msg = Message('Your Assignment Has Been Graded',
                        sender=app.config['MAIL_USERNAME'],
                        recipients=[submission.student.email])
            msg.body = f'Your submission for {submission.assignment.title} has been graded.\nScore: {score}/{submission.assignment.max_score}\nFeedback: {feedback}'
            mail.send(msg)
            
            return redirect(url_for('view_submission', submission_id=submission_id))
        else:
            flash('Invalid score. Please enter a score between 0 and the maximum score.', 'error')
    
    return render_template('grade_submission.html', submission=submission)

# File download routes
@app.route('/download/assignment/<filename>')
@login_required
def download_assignment(filename):
    return send_from_directory(ASSIGNMENTS_FOLDER, filename)

@app.route('/download/submission/<filename>')
@login_required
def download_submission(filename):
    return send_from_directory(SUBMISSIONS_FOLDER, filename)

# AI Assistance route
@app.route('/api/assignment/<assignment_id>/ai-help', methods=['POST'])
def get_ai_help(assignment_id):
    try:
        data = request.get_json()
        user_query = data.get('query', '').strip()

        if not user_query:
            return jsonify({'error': 'No query provided'}), 400

        # Get assignment details
        assignment = Assignment.query.get(assignment_id)
        if not assignment:
            return jsonify({'error': 'Assignment not found'}), 404

        # Check for AI assistance availability
        if not assignment.ai_assistance:
            return jsonify({
                'error': 'AI assistance is not available for this assignment',
                'details': 'Please contact your teacher for help.'
            }), 403

        # Get study material content if available
        study_material_content = ""
        if assignment.study_material_path:
            try:
                file_path = os.path.join(ASSIGNMENTS_FOLDER, assignment.study_material_path)
                study_material_content = read_file_content(file_path)
            except Exception as e:
                print(f"Error reading study material: {str(e)}")

        # Create a context-aware prompt
        prompt = f"""Context: This is an assignment about {assignment.title}.
Description: {assignment.description}
Due Date: {assignment.due_date.strftime('%Y-%m-%d')}
Max Score: {assignment.max_score}

Study Material Content:
{study_material_content[:2000]}  # Increased context length for PDF content

Question: {user_query}

Answer:"""

        # Generate response using the model
        inputs = tokenizer(prompt, return_tensors="pt", max_length=2048, truncation=True)  # Increased max length
        outputs = model.generate(
            inputs["input_ids"],
            max_length=500,  # Increased response length
            num_return_sequences=1,
            temperature=0.7,
            do_sample=True,
            pad_token_id=tokenizer.eos_token_id
        )
        
        response = tokenizer.decode(outputs[0], skip_special_tokens=True)
        
        # Extract only the answer part
        response = response.split("Answer:")[-1].strip()
        
        # Clean up the response
        response = response.replace("\n", " ").strip()
        
        # If response is too short or empty, provide a fallback
        if len(response) < 10:
            response = "I understand your question. Let me help you with that. Could you please provide more details about what you need help with?"

        return jsonify({'response': response})

    except Exception as e:
        app.logger.error(f"Error in AI help: {str(e)}")
        # Ensure we're not returning any HTML content
        if isinstance(e, (ValueError, RuntimeError)):
            error_message = str(e)
        else:
            error_message = 'An unexpected error occurred'
        
        return jsonify({
            'error': error_message,
            'details': 'Please try again or contact your teacher for help.'
        }), 500