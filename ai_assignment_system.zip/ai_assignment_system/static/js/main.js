// Initialize Bootstrap components
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Initialize popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    // AI Query Form Handling
    const aiQueryForm = document.getElementById('aiQueryForm');
    if (aiQueryForm) {
        aiQueryForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const queryInput = document.getElementById('query');
            const aiResponse = document.getElementById('aiResponse');
            const assignmentId = window.location.pathname.split('/').pop();
            
            // Show loading state
            aiResponse.innerHTML = '<div class="text-center"><div class="spinner-border text-primary" role="status"></div><p class="mt-2">Thinking...</p></div>';
            
            // Send query to backend
            fetch(`/api/assignment/${assignmentId}/ai-help`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    query: queryInput.value
                })
            })
            .then(response => {
                if (!response.ok) {
                    return response.json().then(err => Promise.reject(err));
                }
                return response.json();
            })
            .then(data => {
                if (data.error) {
                    throw new Error(data.error);
                }
                // Format and display response
                aiResponse.innerHTML = `<div class="mb-3"><strong>Your question:</strong> ${queryInput.value}</div>
                                       <div><strong>AI response:</strong> ${data.response}</div>`;
                
                // Clear input
                queryInput.value = '';
            })
            .catch(error => {
                const errorMessage = error.details || error.message || 'An unexpected error occurred';
                aiResponse.innerHTML = `<div class="alert alert-danger">${errorMessage}</div>`;
            });
        });
    }

    // Submission grading form
    const gradeForm = document.getElementById('gradeForm');
    if (gradeForm) {
        gradeForm.addEventListener('submit', function(e) {
            const scoreInput = document.getElementById('score');
            const maxScore = parseInt(scoreInput.getAttribute('max'));
            const score = parseInt(scoreInput.value);
            
            if (score > maxScore) {
                e.preventDefault();
                alert(`Score cannot exceed the maximum score of ${maxScore}.`);
            }
        });
    }

    // File input custom styling
    const fileInputs = document.querySelectorAll('.custom-file-input');
    fileInputs.forEach(input => {
        input.addEventListener('change', function(e) {
            const fileName = this.files[0]?.name;
            const label = this.nextElementSibling;
            if (label && fileName) {
                label.textContent = fileName;
            }
        });
    });

    // Due date highlighting
    const dueDates = document.querySelectorAll('.due-date');
    dueDates.forEach(element => {
        const dueDate = new Date(element.getAttribute('data-date'));
        const today = new Date();
        
        // If due date is within 2 days
        if (dueDate - today < 2 * 24 * 60 * 60 * 1000 && dueDate > today) {
            element.classList.add('text-danger', 'fw-bold');
        }
    });
});